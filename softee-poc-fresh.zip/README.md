# Softee POC
Open index.html to view the site.
